$(window).resize(function () {
	$("#block1").css("height", $(window).height()+"px");
	$("#block2").css("height", $(window).height()+"px");
	$("#block3_1").css("height", $(window).height()/1.5+"px");
	$("#block3").css("height", $(window).height()/1.5+"px");
	$("#block4").css("height", $(window).height()+"px");
	$("#block5").css("height", $(window).height()/2+"px");
});

$(document).ready(function () {
	$("#block1").css("height", $(window).height()+"px");
	$("#block2").css("height", $(window).height()+"px");
	$("#block3_1").css("height", $(window).height()/1.5+"px");
	$("#block3").css("height", $(window).height()/1.5+"px");
	$("#block4").css("height", $(window).height()+"px");
	$("#block5").css("height", $(window).height()/2+"px");
});
